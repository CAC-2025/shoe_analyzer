/*
 * Program Name: shoe_analyzer.c
 * Version: 1.0.1
 * Description: Statistical Tool designed to detect alterations in Casino card shoes.
 * Author: Cacarulo
 * Date: 2025-07-31
 * Copyright (C) 2025 Cacarulo. All rights reserved.
 *
 * This program is free software, distributed under the GNU General Public License.
 * See 'gpl.txt' in the project root for full license details.
 *
 * CHANGELOG v1.0.1:
 * - Modified to handle variable sample sizes in files
 * - Removed M,N requirement from file headers (calculated dynamically)
 * - Updated analysis to work with samples of different sizes
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <ctype.h>

// Constants
#define TOTAL_DECKS 6
#define CARDS_PER_DECK 52
#define TOTAL_CARDS (TOTAL_DECKS * CARDS_PER_DECK) // 6 * 52 = 312
#define UNIQUE_CARD_TYPES 52 // 13 values * 4 suits
#define MAX_SAMPLES 5000
#define MAX_SAMPLE_SIZE TOTAL_CARDS
#define BUFFER_SIZE 50
#define HIGH_COUNT_THRESHOLD (TOTAL_DECKS + 1) // 7 for a 6-deck shoe
#define LOW_COUNT_THRESHOLD_PERCENT 95.0
#define Z_CRITICAL_0001 3.291 // For alpha=0.001 (two-tailed)
#define Z_CRITICAL_001 2.576  // For alpha=0.01 (two-tailed)
#define Z_CRITICAL_005 1.960  // For alpha=0.05 (two-tailed)
#define CHI_SQUARED_0001 87.968 // Critical value for alpha=0.001, df=51
#define CHI_SQUARED_001 77.386 // Critical value for alpha=0.01, df=51
#define CHI_SQUARED_005 68.669 // Critical value for alpha=0.05, df=51
#define MAX_LINE_LENGTH 1000

// Global variables for manual M and N
int m_manual = 0;
int n_manual = 0;

// Structures
typedef struct {
    int cards[TOTAL_CARDS + BUFFER_SIZE];
    int size;
} Shoe;

typedef struct {
    int samples[MAX_SAMPLES][UNIQUE_CARD_TYPES];
    int sample_sizes[MAX_SAMPLES]; // New: track individual sample sizes
    int m; // Number of samples
    int n; // Average size of samples (for compatibility)
    int total_observations; // New: total cards across all samples
} Samples;

typedef struct {
    bool is_overall_altered;
    double chi_squared_statistic;
    double p_value_overall;
    bool z_test_altered_overall;
    long long observed_counts[UNIQUE_CARD_TYPES];
    double z_scores[UNIQUE_CARD_TYPES];
    bool specific_card_altered_by_z_test[UNIQUE_CARD_TYPES];
    bool specific_card_altered_by_z_005[UNIQUE_CARD_TYPES];  // alpha=0.05
    bool specific_card_altered_by_z_001[UNIQUE_CARD_TYPES];  // alpha=0.01
    bool specific_card_altered_by_z_0001[UNIQUE_CARD_TYPES]; // alpha=0.001
    bool specific_card_altered_by_high_count[UNIQUE_CARD_TYPES];
    bool specific_card_altered_by_low_count[UNIQUE_CARD_TYPES];
    bool high_count_anomaly_found_any;
    bool low_count_anomaly_found_any;
} AnalysisResult;

// Function Prototypes
void shuffle(int *array, int n);
void create_shoe(Shoe *s, bool altered, int card_to_remove_val, int card_to_remove_suit, 
                 int num_to_remove, int card_to_add_val, int card_to_add_suit, int num_to_add);
void take_samples(Shoe *s, Samples *samples_data, int m, int n);
void save_samples(const char *filename, Samples *samples_data);
bool load_samples(const char *filename, Samples *samples_data);
bool is_line_header(const char *line);
int string_to_card_code(const char *card_str);
char* card_to_string(int card_code);
int card_to_code(int value, int suit);
void get_analysis_results(Samples *samples_data, AnalysisResult *result, int *total_observations_out);
void analyze_samples(Samples *samples_data);
void export_analysis_to_file(Samples *samples_data, AnalysisResult *result, int total_observations);
void print_summary_statistics(AnalysisResult *result);
void option1_set_manual_mn(void);
void option2_generate_normal_file(void);
void option3_generate_altered_file(void);
void option4_analyze_sample_file(void);
void print_menu(void);
bool validate_card_input(int value, int suit);
void clear_input_buffer(void);

// Fisher-Yates shuffle algorithm
void shuffle(int *array, int n) {
    if (n <= 1) return;
    
    for (int i = n - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

// Function to create a shoe (set of decks)
void create_shoe(Shoe *s, bool altered, int card_to_remove_val, int card_to_remove_suit, 
                 int num_to_remove, int card_to_add_val, int card_to_add_suit, int num_to_add) {
    if (s == NULL) {
        printf("Error: Null pointer passed to create_shoe.\n");
        return;
    }
    
    // Initialize shoe with 6 decks (312 cards total)
    s->size = 0;
    for (int deck = 0; deck < TOTAL_DECKS; deck++) {
        for (int card_type = 0; card_type < UNIQUE_CARD_TYPES; card_type++) {
            if (s->size < TOTAL_CARDS + BUFFER_SIZE) {
                s->cards[s->size++] = card_type;
            } else {
                printf("Warning: Shoe capacity exceeded during initialization.\n");
                break;
            }
        }
    }

    // Apply alterations if requested
    if (altered) {
        // Remove cards
        if (num_to_remove > 0) {
            int target_card_code = card_to_code(card_to_remove_val, card_to_remove_suit);
            if (target_card_code == -1) {
                printf("Error: Invalid card to remove specified. Skipping removal.\n");
            } else {
                int removed_count = 0;
                for (int i = 0; i < s->size && removed_count < num_to_remove; ) {
                    if (s->cards[i] == target_card_code) {
                        s->cards[i] = s->cards[s->size - 1];
                        s->size--;
                        removed_count++;
                    } else {
                        i++;
                    }
                }
                
                if (removed_count < num_to_remove) {
                    printf("Warning: Could only remove %d of %d requested cards of %s.\n", 
                           removed_count, num_to_remove, card_to_string(target_card_code));
                }
            }
        }

        // Add cards
        if (num_to_add > 0) {
            int target_card_code = card_to_code(card_to_add_val, card_to_add_suit);
            if (target_card_code == -1) {
                printf("Error: Invalid card to add specified. Skipping addition.\n");
            } else {
                int added_count = 0;
                for (int i = 0; i < num_to_add; i++) {
                    if (s->size < TOTAL_CARDS + BUFFER_SIZE) {
                        s->cards[s->size++] = target_card_code;
                        added_count++;
                    } else {
                        printf("Warning: Shoe capacity reached, could only add %d of %d requested cards of %s.\n", 
                               added_count, num_to_add, card_to_string(target_card_code));
                        break;
                    }
                }
            }
        }
    }

    shuffle(s->cards, s->size);
}

// Function to take samples from a shoe
void take_samples(Shoe *s, Samples *samples_data, int m, int n) {
    if (s == NULL || samples_data == NULL) {
        printf("Error: Null pointer passed to take_samples.\n");
        return;
    }
    
    if (m <= 0 || n <= 0 || m > MAX_SAMPLES || n > MAX_SAMPLE_SIZE) {
        printf("Error: Invalid sample parameters. M=%d, N=%d\n", m, n);
        return;
    }

    samples_data->m = m;
    samples_data->n = n;
    samples_data->total_observations = 0;

    // Initialize all counts to 0
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
            samples_data->samples[i][j] = 0;
        }
        samples_data->sample_sizes[i] = 0;
    }

    // Take samples
    for (int sample_idx = 0; sample_idx < m; sample_idx++) {
        Shoe temp_shoe = *s;
        shuffle(temp_shoe.cards, temp_shoe.size);

        int cards_to_draw = (n < temp_shoe.size) ? n : temp_shoe.size;
        samples_data->sample_sizes[sample_idx] = cards_to_draw;
        samples_data->total_observations += cards_to_draw;
        
        for (int i = 0; i < cards_to_draw; i++) {
            int card_code = temp_shoe.cards[i];
            if (card_code >= 0 && card_code < UNIQUE_CARD_TYPES) {
                samples_data->samples[sample_idx][card_code]++;
            }
        }
    }
}

// Helper function to check if a line is a header line (contains card names)
bool is_line_header(const char *line) {
    // Check if line contains typical card representations
    return (strstr(line, "AC") != NULL || strstr(line, "AD") != NULL || 
            strstr(line, "AH") != NULL || strstr(line, "AS") != NULL ||
            strstr(line, "2C") != NULL || strstr(line, "KC") != NULL);
}

// Helper function to convert card string to card code
int string_to_card_code(const char *card_str) {
    if (strlen(card_str) != 2) return -1;
    
    int value_idx = -1;
    int suit_idx = -1;
    
    // Parse value
    switch (card_str[0]) {
        case 'A': value_idx = 0; break;
        case '2': value_idx = 1; break;
        case '3': value_idx = 2; break;
        case '4': value_idx = 3; break;
        case '5': value_idx = 4; break;
        case '6': value_idx = 5; break;
        case '7': value_idx = 6; break;
        case '8': value_idx = 7; break;
        case '9': value_idx = 8; break;
        case 'T': value_idx = 9; break;
        case 'J': value_idx = 10; break;
        case 'Q': value_idx = 11; break;
        case 'K': value_idx = 12; break;
        default: return -1;
    }
    
    // Parse suit
    switch (card_str[1]) {
        case 'C': suit_idx = 0; break;
        case 'D': suit_idx = 1; break;
        case 'H': suit_idx = 2; break;
        case 'S': suit_idx = 3; break;
        default: return -1;
    }
    
    return value_idx * 4 + suit_idx;
}

// Function to save samples to a file (maintains backward compatibility)
void save_samples(const char *filename, Samples *samples_data) {
    if (filename == NULL || samples_data == NULL) {
        printf("Error: Null pointer passed to save_samples.\n");
        return;
    }
    
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error: Could not open file %s for writing.\n", filename);
        return;
    }

    // Write M and N for backward compatibility
    fprintf(file, "%d %d\n", samples_data->m, samples_data->n);
    
    // Write header with card names
    for (int i = 0; i < UNIQUE_CARD_TYPES; i++) {
        fprintf(file, "%2s ", card_to_string(i));
    }
    fprintf(file, "\n");
    
    // Write sample data
    for (int i = 0; i < samples_data->m; i++) {
        for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
            fprintf(file, "%2d ", samples_data->samples[i][j]);
        }
        fprintf(file, "\n");
    }
    
    fclose(file);
    printf("Successfully saved %d samples to %s\n", samples_data->m, filename);
}

// Enhanced function to load samples from a file (handles both formats)
bool load_samples(const char *filename, Samples *samples_data) {
    if (filename == NULL || samples_data == NULL) {
        printf("Error: Null pointer passed to load_samples.\n");
        return false;
    }
    
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error: Could not open file %s for reading.\n", filename);
        samples_data->m = 0;
        samples_data->n = 0;
        samples_data->total_observations = 0;
        return false;
    }

    char line[MAX_LINE_LENGTH];
    samples_data->m = 0;
    samples_data->total_observations = 0;
    bool has_mn_header = false;
    bool has_card_header = false;
    int line_number = 0;

    // Initialize
    for (int i = 0; i < MAX_SAMPLES; i++) {
        for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
            samples_data->samples[i][j] = 0;
        }
        samples_data->sample_sizes[i] = 0;
    }

    // First pass: determine file format and count samples
    while (fgets(line, sizeof(line), file) && samples_data->m < MAX_SAMPLES) {
        line_number++;
        
        // Remove trailing whitespace
        char *end = line + strlen(line) - 1;
        while (end > line && isspace((unsigned char)*end)) end--;
        *(end + 1) = '\0';
        
        // Skip empty lines
        if (strlen(line) == 0) continue;
        
        // Check first line for M N format
        if (line_number == 1) {
            int temp_m, temp_n;
            if (sscanf(line, "%d %d", &temp_m, &temp_n) == 2 && temp_m > 0 && temp_n > 0) {
                has_mn_header = true;
                continue;
            }
        }
        
        // Check for card header line
        if (is_line_header(line)) {
            has_card_header = true;
            continue;
        }
        
        // This should be a data line - count it as a sample
        samples_data->m++;
    }
    
    if (samples_data->m == 0) {
        printf("Error: No valid samples found in file %s.\n", filename);
        fclose(file);
        return false;
    }

    // Second pass: read the actual data
    rewind(file);
    line_number = 0;
    int current_sample = 0;
    
    while (fgets(line, sizeof(line), file) && current_sample < samples_data->m) {
        line_number++;
        
        // Remove trailing whitespace
        char *end = line + strlen(line) - 1;
        while (end > line && isspace((unsigned char)*end)) end--;
        *(end + 1) = '\0';
        
        // Skip empty lines
        if (strlen(line) == 0) continue;
        
        // Skip M N header if present
        if (has_mn_header && line_number == 1) continue;
        
        // Skip card header if present
        if (has_card_header && is_line_header(line)) continue;
        
        // Parse data line
        char *token = strtok(line, " \t");
        int card_index = 0;
        int sample_total = 0;
        
        while (token != NULL && card_index < UNIQUE_CARD_TYPES) {
            int count = atoi(token);
            if (count < 0) count = 0; // Handle negative values
            
            samples_data->samples[current_sample][card_index] = count;
            sample_total += count;
            card_index++;
            token = strtok(NULL, " \t");
        }
        
        samples_data->sample_sizes[current_sample] = sample_total;
        samples_data->total_observations += sample_total;
        current_sample++;
    }
    
    // Calculate average sample size
    samples_data->n = (samples_data->m > 0) ? samples_data->total_observations / samples_data->m : 0;
    
    fclose(file);
    
    printf("Successfully loaded %d samples from %s\n", samples_data->m, filename);
    printf("Total observations: %d cards (average %.1f cards per sample)\n", 
           samples_data->total_observations, (double)samples_data->total_observations / samples_data->m);
    
    // Show sample size distribution
    int min_size = samples_data->sample_sizes[0];
    int max_size = samples_data->sample_sizes[0];
    for (int i = 1; i < samples_data->m; i++) {
        if (samples_data->sample_sizes[i] < min_size) min_size = samples_data->sample_sizes[i];
        if (samples_data->sample_sizes[i] > max_size) max_size = samples_data->sample_sizes[i];
    }
    
    if (min_size != max_size) {
        printf("Variable sample sizes detected: min=%d, max=%d cards per sample\n", min_size, max_size);
    }
    
    return true;
}

// Helper to convert card code to string
char* card_to_string(int card_code) {
    static char str[4];
    const char* values[] = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K"};
    const char* suits[] = {"C", "D", "H", "S"};

    if (card_code < 0 || card_code >= UNIQUE_CARD_TYPES) {
        strcpy(str, "??");
        return str;
    }

    int value = card_code / 4;
    int suit = card_code % 4;

    sprintf(str, "%s%s", values[value], suits[suit]);
    return str;
}

// Helper to convert card value and suit to card code
int card_to_code(int value, int suit) {
    int val_idx;
    
    if (value >= 2 && value <= 9) {
        val_idx = value - 1;
    } else if (value == 1) {
        val_idx = 0; // Ace
    } else if (value == 10) {
        val_idx = 9; // Ten
    } else if (value == 11) {
        val_idx = 10; // Jack
    } else if (value == 12) {
        val_idx = 11; // Queen
    } else if (value == 13) {
        val_idx = 12; // King
    } else {
        return -1; // Invalid value
    }
    
    if (suit < 0 || suit > 3) {
        return -1; // Invalid suit
    }
    
    return val_idx * 4 + suit;
}

// Performs the core analysis logic and populates an AnalysisResult struct
void get_analysis_results(Samples *samples_data, AnalysisResult *result, int *total_observations_out) {
    if (samples_data == NULL || result == NULL || total_observations_out == NULL) {
        printf("Error: Null pointer passed to get_analysis_results.\n");
        return;
    }
    
    // Initialize result struct
    memset(result, 0, sizeof(AnalysisResult));

    int total_observations = samples_data->total_observations;
    *total_observations_out = total_observations;

    if (total_observations == 0) {
        printf("Error: No observations to analyze.\n");
        return;
    }

    double expected_probability = 1.0 / UNIQUE_CARD_TYPES;
    double total_observations_double = (double)total_observations;

    // Calculate observed counts for each card type across all samples
    for (int i = 0; i < samples_data->m; i++) {
        for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
            result->observed_counts[j] += samples_data->samples[i][j];
        }
    }

    // Calculate Chi-squared statistic
    double ideal_expected_count = expected_probability * total_observations_double;
    for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
        double diff = result->observed_counts[j] - ideal_expected_count;
        result->chi_squared_statistic += (diff * diff) / ideal_expected_count;
    }

    // Determine p-value based on chi-squared statistic
    if (result->chi_squared_statistic > CHI_SQUARED_0001) {
        result->p_value_overall = 0.001;
    } else if (result->chi_squared_statistic > CHI_SQUARED_001) {
        result->p_value_overall = 0.01;
    } else if (result->chi_squared_statistic > CHI_SQUARED_005) {
        result->p_value_overall = 0.05;
    } else {
        result->p_value_overall = 1.0;
    }

    // Z-test for individual cards with multiple thresholds
    for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
        double p_hat = (double)result->observed_counts[j] / total_observations_double;
        double std_err = sqrt(expected_probability * (1 - expected_probability) / total_observations_double);
        
        if (std_err > 0) {
            result->z_scores[j] = (p_hat - expected_probability) / std_err;

            // Check different significance levels
            double abs_z = fabs(result->z_scores[j]);
            
            if (abs_z >= Z_CRITICAL_0001) {
                result->specific_card_altered_by_z_0001[j] = true;
                result->specific_card_altered_by_z_001[j] = true;
                result->specific_card_altered_by_z_005[j] = true;
                result->specific_card_altered_by_z_test[j] = true;
            } else if (abs_z >= Z_CRITICAL_001) {
                result->specific_card_altered_by_z_001[j] = true;
                result->specific_card_altered_by_z_005[j] = true;
                result->specific_card_altered_by_z_test[j] = true;
            } else if (abs_z >= Z_CRITICAL_005) {
                result->specific_card_altered_by_z_005[j] = true;
                result->specific_card_altered_by_z_test[j] = true;
            }

            // Set overall flag if ANY card exceeds the lowest threshold (most sensitive)
            if (abs_z >= Z_CRITICAL_005) {
                result->z_test_altered_overall = true;
            }
        }
    }

    // High count anomaly detection
    for (int i = 0; i < samples_data->m; i++) {
        for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
            if (samples_data->samples[i][j] >= HIGH_COUNT_THRESHOLD) {
                result->specific_card_altered_by_high_count[j] = true;
                result->high_count_anomaly_found_any = true;
            }
        }
    }

    // Low count anomaly detection
    for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
        int zero_count_samples = 0;
        for (int i = 0; i < samples_data->m; i++) {
            if (samples_data->samples[i][j] == 0) {
                zero_count_samples++;
            }
        }
        
        double percent_zero = (double)zero_count_samples / samples_data->m * 100.0;
        
        if (percent_zero >= LOW_COUNT_THRESHOLD_PERCENT && 
            result->observed_counts[j] < ideal_expected_count * 0.5) {
            result->specific_card_altered_by_low_count[j] = true;
            result->low_count_anomaly_found_any = true;
        }
    }

    // Overall result determination
    result->is_overall_altered = (result->p_value_overall < 0.05 || 
                                 result->z_test_altered_overall || 
                                 result->high_count_anomaly_found_any || 
                                 result->low_count_anomaly_found_any);
}

// Function to analyze samples for anomalies
void analyze_samples(Samples *samples_data) {
    if (samples_data == NULL || samples_data->m == 0 || samples_data->total_observations == 0) {
        printf("No samples to analyze. Please generate samples first.\n");
        return;
    }

    AnalysisResult analysis_res;
    int total_observations;
    get_analysis_results(samples_data, &analysis_res, &total_observations);

    printf("\n--- SAMPLE ANALYSIS ---\n");
    printf("Total samples (M): %d\n", samples_data->m);
    printf("Total observations: %d cards analyzed\n", total_observations);
    printf("Average sample size: %.1f cards per sample\n", (double)total_observations / samples_data->m);
    
    // Show sample size distribution
    int min_size = samples_data->sample_sizes[0];
    int max_size = samples_data->sample_sizes[0];
    for (int i = 1; i < samples_data->m; i++) {
        if (samples_data->sample_sizes[i] < min_size) min_size = samples_data->sample_sizes[i];
        if (samples_data->sample_sizes[i] > max_size) max_size = samples_data->sample_sizes[i];
    }
    
    if (min_size != max_size) {
        printf("Sample size range: %d to %d cards per sample\n", min_size, max_size);
    } else {
        printf("Uniform sample size: %d cards per sample\n", min_size);
    }
    
    // Chi-squared explanation
    printf("\nChi-squared statistic (overall): %.3f\n", analysis_res.chi_squared_statistic);
    printf("  -> This measures how much the observed card distribution deviates from expected.\n");
    printf("  -> Higher values indicate more deviation (potential alteration).\n");
    printf("  -> Critical thresholds: 68.669 (significant), 77.386 (very significant), 87.968 (extreme)\n");
    
    // P-value explanation with interpretation
    printf("\nP-value (overall): %.3f", analysis_res.p_value_overall);
    if (analysis_res.p_value_overall <= 0.001) {
        printf(" *** EXTREMELY SIGNIFICANT ***\n");
        printf("  -> Less than 0.1%% chance this distribution occurred naturally.\n");
        printf("  -> STRONG evidence of shoe alteration.\n");
    } else if (analysis_res.p_value_overall <= 0.01) {
        printf(" ** VERY SIGNIFICANT **\n");
        printf("  -> Less than 1%% chance this distribution occurred naturally.\n");
        printf("  -> SUBSTANTIAL evidence of shoe alteration.\n");
    } else if (analysis_res.p_value_overall <= 0.05) {
        printf(" * SIGNIFICANT *\n");
        printf("  -> Less than 5%% chance this distribution occurred naturally.\n");
        printf("  -> MODERATE evidence of shoe alteration.\n");
    } else {
        printf(" (Not significant)\n");
        printf("  -> %.1f%% or higher chance this distribution occurred naturally.\n", analysis_res.p_value_overall * 100);
        printf("  -> NO statistical evidence of shoe alteration.\n");
    }
    
    // Summary interpretation
    printf("\nChi-squared Interpretation:\n");
    if (analysis_res.chi_squared_statistic > CHI_SQUARED_0001) {
        printf("  Status: DEFINITIVELY ALTERED SHOE (Chi-squared = %.3f > 87.968)\n", 
               analysis_res.chi_squared_statistic);
        printf("  -> Extremely strong evidence of manipulation.\n");
    } else if (analysis_res.chi_squared_statistic > CHI_SQUARED_001) {
        printf("  Status: ALTERED SHOE DETECTED (Chi-squared = %.3f > 77.386)\n", 
               analysis_res.chi_squared_statistic);
        printf("  -> Strong evidence of shoe alteration.\n");
    } else if (analysis_res.chi_squared_statistic > CHI_SQUARED_005) {
        printf("  Status: SUSPICIOUS DISTRIBUTION (Chi-squared = %.3f > 68.669)\n", 
               analysis_res.chi_squared_statistic);
        printf("  -> Moderate evidence suggesting possible alteration.\n");
    } else {
        printf("  Status: NORMAL DISTRIBUTION (Chi-squared = %.3f <= 68.669)\n", 
               analysis_res.chi_squared_statistic);
        printf("  -> The card frequencies appear consistent with a fair 6-deck shoe.\n");
    }

    // Detailed Card Type Analysis
    printf("\n--- Detailed Card Type Analysis (Z-test) ---\n");
    printf("+------+--------------+--------------+----------------+---------+-----------+\n");
    printf("| Card | Observed Pct | Expected Pct | Pct Difference | Z-Score | Sig Level |\n");
    printf("+------+--------------+--------------+----------------+---------+-----------+\n");

    double expected_probability = 1.0 / UNIQUE_CARD_TYPES;
    double total_observations_double = (double)total_observations;

    for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
        double observed_pct = (double)analysis_res.observed_counts[j] / total_observations_double * 100.0;
        double expected_pct = expected_probability * 100.0;
        double pct_difference = observed_pct - expected_pct;

        // Determine the specific significance level
        const char* significance_level;
        if (analysis_res.specific_card_altered_by_z_0001[j]) {
            significance_level = "EXTREME";
        } else if (analysis_res.specific_card_altered_by_z_001[j]) {
            significance_level = "STRONG";
        } else if (analysis_res.specific_card_altered_by_z_005[j]) {
            significance_level = "MODERATE";
        } else {
            significance_level = "NORMAL";
        }

        printf("|  %2s  | %11.2f%% | %11.2f%% | %13.2f%% | %7.2f | %-9s |\n", 
               card_to_string(j), observed_pct, expected_pct, pct_difference, 
               analysis_res.z_scores[j], significance_level);
    }
    printf("+------+--------------+--------------+----------------+---------+-----------+\n");
    
    // Add explanation of significance levels
    printf("\nSignificance Legend:\n");
    printf("  EXTREME  : EXTREME evidence of alteration (alpha < 0.001, 99.9%% confidence)\n");
    printf("  STRONG   : STRONG evidence of alteration (alpha < 0.01, 99%% confidence)\n");
    printf("  MODERATE : MODERATE evidence of alteration (alpha < 0.05, 95%% confidence)\n");
    printf("  NORMAL   : No statistical evidence of alteration\n");

    // High count anomaly detection
    printf("\n--- Per-Sample Anomaly Detection (High Count Only) ---\n");
    if (analysis_res.high_count_anomaly_found_any) {
        for (int i = 0; i < samples_data->m; i++) {
            for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
                if (samples_data->samples[i][j] >= HIGH_COUNT_THRESHOLD) {
                    printf("  ALERT (HIGH Count): Sample %2d contained %d copies of Card %s "
                           "(threshold %d). This indicates ALTERATION (Card Added).\n",
                           i + 1, samples_data->samples[i][j], card_to_string(j), HIGH_COUNT_THRESHOLD);
                }
            }
        }
        printf("  (Note: High count anomalies (>=%d) are definitive proof of alteration.)\n", 
               HIGH_COUNT_THRESHOLD);
    } else {
        printf("  No high count anomalies (>=%d) detected in any single sample.\n", 
               HIGH_COUNT_THRESHOLD);
    }

    // Low count anomaly detection
    printf("\n--- Consistent Low Count Detection ---\n");
    if (analysis_res.low_count_anomaly_found_any) {
        for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
            if (analysis_res.specific_card_altered_by_low_count[j]) {
                int zero_count_samples = 0;
                for (int i = 0; i < samples_data->m; i++) {
                    if (samples_data->samples[i][j] == 0) {
                        zero_count_samples++;
                    }
                }
                double percent_zero = (double)zero_count_samples / samples_data->m * 100.0;
                printf("  ALERT (LOW Count): Card %s observed 0 copies in %.2f%% of samples "
                       "(threshold %.2f%%). This indicates ALTERATION (Card Removed).\n",
                       card_to_string(j), percent_zero, LOW_COUNT_THRESHOLD_PERCENT);
            }
        }
    } else {
        printf("  No card type consistently observed missing (0 copies) across samples.\n");
    }

    // Overall Result
    printf("\n--- Overall Result ---\n");
    if (analysis_res.is_overall_altered) {
        printf("FINAL RESULT: The shoe appears ALTERED\n");
        if (analysis_res.p_value_overall < 0.05) {
            printf("  - Overall Chi-squared P-value (%.4f) is below significance threshold (0.05).\n", 
                   analysis_res.p_value_overall);
        }
        if (analysis_res.z_test_altered_overall) {
            printf("  - Individual Card Z-tests detected significant frequency deviations.\n");
        }
        if (analysis_res.high_count_anomaly_found_any) {
            printf("  - Per-sample anomaly: HIGH count (>=%d) detected in at least one sample.\n", 
                   HIGH_COUNT_THRESHOLD);
        }
        if (analysis_res.low_count_anomaly_found_any) {
            printf("  - Consistent LOW count detected, indicating missing cards.\n");
        }
    } else {
        printf("FINAL RESULT: The shoe appears NORMAL (no significant alterations detected).\n");
    }
    
    // Print summary statistics
    print_summary_statistics(&analysis_res);
    
    // Ask if user wants to export results
    printf("\nExport detailed analysis to file? (y/n): ");
    char export_choice;
    if (scanf(" %c", &export_choice) == 1 && (export_choice == 'y' || export_choice == 'Y')) {
        export_analysis_to_file(samples_data, &analysis_res, total_observations);
    }
}

// Utility functions
bool validate_card_input(int value, int suit) {
    return (value >= 1 && value <= 13 && suit >= 0 && suit <= 3);
}

void clear_input_buffer(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

void print_menu(void) {
    printf("1. Set Manual M and N\n");
    printf("2. Generate Normal Shoe Samples File (normal.txt)\n");
    printf("3. Generate Altered Shoe Samples File (altered.txt)\n");
    printf("4. Analyze Sample File\n");
    printf("5. Exit\n\n");
    printf("Select an option: ");
    fflush(stdout);
}

// Option functions
void option1_set_manual_mn(void) {
    printf("Enter Manual M (number of samples, 1-%d): ", MAX_SAMPLES);
    if (scanf("%d", &m_manual) != 1) {
        printf("Invalid input for M.\n");
        clear_input_buffer();
        return;
    }
    
    printf("Enter Manual N (size of each sample, 1-%d): ", MAX_SAMPLE_SIZE);
    if (scanf("%d", &n_manual) != 1) {
        printf("Invalid input for N.\n");
        clear_input_buffer();
        return;
    }
    
    if (m_manual <= 0 || n_manual <= 0 || m_manual > MAX_SAMPLES || n_manual > MAX_SAMPLE_SIZE) {
        printf("M and N must be positive integers within valid ranges. Resetting to 0.\n");
        m_manual = 0;
        n_manual = 0;
        return;
    }

    // Validation for statistical reliability
    if (m_manual * n_manual < 1000) {
        printf("WARNING: Small sample size (M*N = %d). For reliable statistical analysis,\n", m_manual * n_manual);
        printf("         consider using M*N >= 1000. Continue anyway? (y/n): ");
        char confirm;
        if (scanf(" %c", &confirm) != 1 || (confirm != 'y' && confirm != 'Y')) {
            printf("Operation cancelled.\n");
            return;
        }
    }
    
    printf("Manual M=%d, N=%d set successfully.\n", m_manual, n_manual);
}

void option2_generate_normal_file(void) {
    if (!m_manual && !n_manual) {
        printf("M and N are not set.\n");
        return;
    }
    Shoe normal_shoe;
    create_shoe(&normal_shoe, false, 0, 0, 0, 0, 0, 0);

    Samples normal_samples;
    take_samples(&normal_shoe, &normal_samples, m_manual, n_manual);

    save_samples("normal.txt", &normal_samples);
}

void option3_generate_altered_file(void) {
    if (!m_manual && !n_manual) {
        printf("M and N are not set.\n");
        return;
    }
    char choice;
    int r_val = 0, r_suit = 0, r_qty = 0;
    int a_val = 0, a_suit = 0, a_qty = 0;

    printf("\nChoose alteration type:\n\n");
    printf("  a. Remove n cards and Add m cards (Net change possible)\n");
    printf("  b. Remove n cards only (Fewer total cards)\n");
    printf("  c. Add n cards only (More total cards)\n\n");
    printf("Enter choice (a/b/c): ");
    
    if (scanf(" %c", &choice) != 1) {
        printf("Invalid input.\n");
        clear_input_buffer();
        return;
    }

    switch (choice) {
        case 'a':
        case 'A':
            printf("--- Configure Removal ---\n");
            printf("  Card VALUE to remove (1-13, 1=A, 10=T, 11=J, 12=Q, 13=K): ");
            if (scanf("%d", &r_val) != 1) {
                printf("Invalid input for removal value.\n");
                clear_input_buffer();
                return;
            }
            printf("  Card SUIT to remove (0=C, 1=D, 2=H, 3=S): ");
            if (scanf("%d", &r_suit) != 1) {
                printf("Invalid input for removal suit.\n");
                clear_input_buffer();
                return;
            }
            printf("  QUANTITY of cards to remove: ");
            if (scanf("%d", &r_qty) != 1) {
                printf("Invalid input for removal quantity.\n");
                clear_input_buffer();
                return;
            }

            printf("--- Configure Addition ---\n");
            printf("  Card VALUE to add (1-13, 1=A, 10=T, 11=J, 12=Q, 13=K): ");
            if (scanf("%d", &a_val) != 1) {
                printf("Invalid input for addition value.\n");
                clear_input_buffer();
                return;
            }
            printf("  Card SUIT to add (0=C, 1=D, 2=H, 3=S): ");
            if (scanf("%d", &a_suit) != 1) {
                printf("Invalid input for addition suit.\n");
                clear_input_buffer();
                return;
            }
            printf("  QUANTITY of cards to add: ");
            if (scanf("%d", &a_qty) != 1) {
                printf("Invalid input for addition quantity.\n");
                clear_input_buffer();
                return;
            }
            break;
            
        case 'b':
        case 'B':
            printf("--- Configure Removal Only ---\n");
            printf("  Card VALUE to remove (1-13, 1=A, 10=T, 11=J, 12=Q, 13=K): ");
            if (scanf("%d", &r_val) != 1) {
                printf("Invalid input for removal value.\n");
                clear_input_buffer();
                return;
            }
            printf("  Card SUIT to remove (0=C, 1=D, 2=H, 3=S): ");
            if (scanf("%d", &r_suit) != 1) {
                printf("Invalid input for removal suit.\n");
                clear_input_buffer();
                return;
            }
            printf("  QUANTITY of cards to remove: ");
            if (scanf("%d", &r_qty) != 1) {
                printf("Invalid input for removal quantity.\n");
                clear_input_buffer();
                return;
            }
            break;
            
        case 'c':
        case 'C':
            printf("--- Configure Addition Only ---\n");
            printf("  Card VALUE to add (1-13, 1=A, 10=T, 11=J, 12=Q, 13=K): ");
            if (scanf("%d", &a_val) != 1) {
                printf("Invalid input for addition value.\n");
                clear_input_buffer();
                return;
            }
            printf("  Card SUIT to add (0=C, 1=D, 2=H, 3=S): ");
            if (scanf("%d", &a_suit) != 1) {
                printf("Invalid input for addition suit.\n");
                clear_input_buffer();
                return;
            }
            printf("  QUANTITY of cards to add: ");
            if (scanf("%d", &a_qty) != 1) {
                printf("Invalid input for addition quantity.\n");
                clear_input_buffer();
                return;
            }
            break;
            
        default:
            printf("Invalid choice. No altered file generated.\n");
            return;
    }

    // Validate inputs
    if (r_qty > 0 && !validate_card_input(r_val, r_suit)) {
        printf("Invalid card to remove specified. No alteration applied for removal.\n");
        r_qty = 0;
    }
    if (a_qty > 0 && !validate_card_input(a_val, a_suit)) {
        printf("Invalid card to add specified. No alteration applied for addition.\n");
        a_qty = 0;
    }
    if (r_qty < 0 || a_qty < 0) {
        printf("Quantities must be non-negative.\n");
        return;
    }

    if (r_qty == 0 && a_qty == 0) {
        printf("No valid alteration specified. Altered file will not be generated.\n");
        return;
    }

    Shoe altered_shoe;
    create_shoe(&altered_shoe, true, r_val, r_suit, r_qty, a_val, a_suit, a_qty);

    Samples altered_samples;
    take_samples(&altered_shoe, &altered_samples, m_manual, n_manual);

    save_samples("altered.txt", &altered_samples);
    printf("Remember to use significant alterations for testing detection.\n");
}

void option4_analyze_sample_file(void) {
    char filename[256];
    printf("Enter filename to analyze: ");
    if (scanf("%255s", filename) != 1) {
        printf("Invalid filename input.\n");
        clear_input_buffer();
        return;
    }
    
    Samples samples_data;
    if (load_samples(filename, &samples_data)) {
        analyze_samples(&samples_data);
    }
}

// Function to print summary statistics
void print_summary_statistics(AnalysisResult *result) {
    int extreme_count = 0, strong_count = 0, moderate_count = 0, normal_count = 0;
    
    for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
        if (result->specific_card_altered_by_z_0001[j]) {
            extreme_count++;
        } else if (result->specific_card_altered_by_z_001[j]) {
            strong_count++;
        } else if (result->specific_card_altered_by_z_005[j]) {
            moderate_count++;
        } else {
            normal_count++;
        }
    }
    
    printf("\n--- SUMMARY STATISTICS ---\n");
    printf("Card Distribution Analysis:\n");
    printf("  EXTREME alterations:  %2d cards (alpha < 0.001)\n", extreme_count);
    printf("  STRONG alterations:   %2d cards (alpha < 0.01)\n", strong_count);
    printf("  MODERATE alterations: %2d cards (alpha < 0.05)\n", moderate_count);
    printf("  NORMAL distribution:  %2d cards\n", normal_count);
    printf("  Total cards analyzed: %2d\n", UNIQUE_CARD_TYPES);
    
    int total_altered = extreme_count + strong_count + moderate_count;
    double altered_percentage = (double)total_altered / UNIQUE_CARD_TYPES * 100.0;
    
    printf("\nOverall Assessment:\n");
    printf("  Cards showing alteration: %d out of %d (%.1f%%)\n", 
           total_altered, UNIQUE_CARD_TYPES, altered_percentage);
    
    if (total_altered == 0) {
        printf("  Assessment: CLEAN SHOE - No statistical evidence of manipulation\n");
    } else if (extreme_count > 0) {
        printf("  Assessment: DEFINITELY ALTERED - Extreme statistical evidence present\n");
    } else if (strong_count > 0) {
        printf("  Assessment: LIKELY ALTERED - Strong statistical evidence present\n");
    } else {
        printf("  Assessment: POSSIBLY ALTERED - Moderate statistical evidence present\n");
    }
}

// Function to export analysis results to file
void export_analysis_to_file(Samples *samples_data, AnalysisResult *result, int total_observations) {
    char filename[256];
    printf("Enter filename for export (e.g., report.txt): ");
    if (scanf("%255s", filename) != 1) {
        printf("Invalid filename. Export cancelled.\n");
        return;
    }
    
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error: Could not create file %s for writing.\n", filename);
        return;
    }
    
    // Get current time
    time_t now = time(NULL);
    char *time_str = ctime(&now);
    time_str[strlen(time_str) - 1] = '\0'; // Remove newline
    
    fprintf(file, "=== CARD SHOE ANALYSIS REPORT ===\n");
    fprintf(file, "Generated: %s\n", time_str);
    fprintf(file, "Sample Parameters: M=%d (Total observations: %d)\n", 
            samples_data->m, total_observations);
    fprintf(file, "Average sample size: %.1f cards per sample\n\n", 
            (double)total_observations / samples_data->m);
    
    // Show sample size distribution in report
    int min_size = samples_data->sample_sizes[0];
    int max_size = samples_data->sample_sizes[0];
    for (int i = 1; i < samples_data->m; i++) {
        if (samples_data->sample_sizes[i] < min_size) min_size = samples_data->sample_sizes[i];
        if (samples_data->sample_sizes[i] > max_size) max_size = samples_data->sample_sizes[i];
    }
    
    if (min_size != max_size) {
        fprintf(file, "Sample size range: %d to %d cards per sample\n\n", min_size, max_size);
    } else {
        fprintf(file, "Uniform sample size: %d cards per sample\n\n", min_size);
    }
    
    // Overall statistics
    fprintf(file, "OVERALL ANALYSIS:\n");
    fprintf(file, "Chi-squared statistic: %.3f\n", result->chi_squared_statistic);
    fprintf(file, "P-value: %.4f\n", result->p_value_overall);
    fprintf(file, "Overall result: %s\n\n", 
            result->is_overall_altered ? "ALTERED" : "NORMAL");
    
    // Detailed Card Type Analysis
    fprintf(file, "--- Detailed Card Type Analysis (Z-test) ---\n");
    fprintf(file, "+------+--------------+--------------+----------------+---------+-----------+\n");
    fprintf(file, "| Card | Observed Pct | Expected Pct | Pct Difference | Z-Score | Sig Level |\n");
    fprintf(file, "+------+--------------+--------------+----------------+---------+-----------+\n");
    
    double expected_probability = 1.0 / UNIQUE_CARD_TYPES;
    double total_observations_double = (double)total_observations;
    
    for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
        double observed_pct = (double)result->observed_counts[j] / total_observations_double * 100.0;
        double expected_pct = expected_probability * 100.0;
        double pct_difference = observed_pct - expected_pct;
        
        const char* significance_level;
        if (result->specific_card_altered_by_z_0001[j]) {
            significance_level = "EXTREME";
        } else if (result->specific_card_altered_by_z_001[j]) {
            significance_level = "STRONG";
        } else if (result->specific_card_altered_by_z_005[j]) {
            significance_level = "MODERATE";
        } else {
            significance_level = "NORMAL";
        }
        
        fprintf(file, "|  %2s  | %11.2f%% | %11.2f%% | %13.2f%% | %7.2f | %-9s |\n", 
               card_to_string(j), observed_pct, expected_pct, pct_difference, 
               result->z_scores[j], significance_level);
    }

    fprintf(file, "+------+--------------+--------------+----------------+---------+-----------+\n");
    
    // Add explanation of significance levels
    fprintf(file, "\nSignificance Legend:\n");
    fprintf(file, "  EXTREME  : EXTREME evidence of alteration (alpha < 0.001, 99.9%% confidence)\n");
    fprintf(file, "  STRONG   : STRONG evidence of alteration (alpha < 0.01, 99%% confidence)\n");
    fprintf(file, "  MODERATE : MODERATE evidence of alteration (alpha < 0.05, 95%% confidence)\n");
    fprintf(file, "  NORMAL   : No statistical evidence of alteration\n");

    // Summary statistics
    int extreme_count = 0, strong_count = 0, moderate_count = 0, normal_count = 0;
    for (int j = 0; j < UNIQUE_CARD_TYPES; j++) {
        if (result->specific_card_altered_by_z_0001[j]) {
            extreme_count++;
        } else if (result->specific_card_altered_by_z_001[j]) {
            strong_count++;
        } else if (result->specific_card_altered_by_z_005[j]) {
            moderate_count++;
        } else {
            normal_count++;
        }
    }
    
    fprintf(file, "\nSUMMARY STATISTICS:\n");
    fprintf(file, "EXTREME alterations:  %2d cards\n", extreme_count);
    fprintf(file, "STRONG alterations:   %2d cards\n", strong_count);
    fprintf(file, "MODERATE alterations: %2d cards\n", moderate_count);
    fprintf(file, "NORMAL distribution:  %2d cards\n", normal_count);
    
    int total_altered = extreme_count + strong_count + moderate_count;
    double altered_percentage = (double)total_altered / UNIQUE_CARD_TYPES * 100.0;
    fprintf(file, "Cards showing alteration: %d out of %d (%.1f%%)\n", 
            total_altered, UNIQUE_CARD_TYPES, altered_percentage);
    
    // Anomaly details
    if (result->high_count_anomaly_found_any || result->low_count_anomaly_found_any) {
        fprintf(file, "\nANOMALY DETAILS:\n");
        
        if (result->high_count_anomaly_found_any) {
            fprintf(file, "High count anomalies detected (cards appearing >=%d times in single sample)\n", 
                    HIGH_COUNT_THRESHOLD);
        }
        
        if (result->low_count_anomaly_found_any) {
            fprintf(file, "Low count anomalies detected (cards missing from >=%.1f%% of samples)\n", 
                    LOW_COUNT_THRESHOLD_PERCENT);
        }
    }
    
    fclose(file);
    printf("Analysis results exported to: %s\n", filename);
}

int main(void) {
    printf("=== CARD SHOE ANALYZER - Version 1.0.1 ===\n\n");
    printf("Copyright (C) 2025 Cacarulo. All rights reserved.\n\n");
    printf("This program is free software, distributed under the GNU General Public License.\n");
    printf("See 'gpl.txt' in the project root for full license details.\n\n");

    int option;
    srand((unsigned int)time(NULL));

    do {
        print_menu();
        
        if (scanf("%d", &option) != 1) {
            printf("Invalid input. Please enter a number.\n");
            clear_input_buffer();
            continue;
        }

        switch(option) {
            case 1: 
                printf ("\n");
                option1_set_manual_mn(); 
                printf ("\n");
                break;
            case 2: 
                printf ("\n");
                option2_generate_normal_file(); 
                printf ("\n");
                break;
            case 3: 
                printf ("\n");
                option3_generate_altered_file(); 
                printf ("\n");
                break;
            case 4: 
                printf ("\n");
                option4_analyze_sample_file(); 
                printf ("\n");
                break;
            case 5: 
                break;
            default: 
                printf("Invalid option. Please select 1-5.\n"); 
                break;
        }
    } while (option != 5);

    return 0;
}
